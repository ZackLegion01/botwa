 {
 "contactOwner": "628xxx", 
 "botName": "Nama Bot", 
 "ownerName": "Nama Owner", 
 "sessionName": "session", 
 "footer": "Nama Bot © 2022", 
 "packname": "Nama Bot", 
 "author": "Nama Owner", 

 "youtube": "YouTube", 
 "github": "Github", 
 "instagram": "Instagram", 
 "tiktok": "TikTok", 
 "website": "Website", 
 "email": "Email", 
 "gender": "Gender/Jenis Kelamin", 
 "agama": "Agama", 
 "tanggallahir": "Tanggal Lahir", 
 "umur": "Umur", 
 "kelas": "Kelas", 
 "hobi": "Hobi", 
 "sifat": "Sifat", 
 "tinggal": "Tempat Tinggal", 
 "suka": "Kesukaan", 
 "benci": "Kebencian", 
 
  "api_alpha": "https://alphabot-api.herokuapp.com", 
  "apikey_alpha": "APIKEY", 
  
  "api_ronzz": "https://ronzz-api.herokuapp.com", 
  "apikey_ronzz": "APIKEY", 
 
 "api_zenz": "lexxybotygy", 
 "apikey_antlatic": "APIKEY", 

 "payment": {
    "qris": {
      "link_nya": "Link Qris/Foto qris", 
      "atas_nama": "Nama" 
    },
    "dana": {
      "nomer": "Nomor Dana", 
      "atas_nama": "Nama" 
    }},
    
  "pathQris": "./temp/media/qris.jpg", 
  "pathCont": "./temp/media/contributor.jpg", 
  "pathBc": "./temp/media/bc.jpg", 
  "pathThumb": "./temp/media/logoNya.jpg", 
  "pathThumb2": "./temp/media/logo.jpg", 
  "pathMenfes": "./temp/media/menfes.jpg" 
  }